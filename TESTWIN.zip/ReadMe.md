[Sun 10/12/2025  4:44:37.17] BILGI TOPLAMA BASLATILDI 
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 1: internet sifresi: 
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 2: sc query type driver: 

SERVICE_NAME: ACPI
DISPLAY_NAME: Microsoft ACPI S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: acpiex
DISPLAY_NAME: Microsoft ACPIEx Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: AFD
DISPLAY_NAME: Winsock I�in Yardimci Islev S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: afunix
DISPLAY_NAME: afunix
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ahcache
DISPLAY_NAME: Application Compatibility Cache
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: bam
DISPLAY_NAME: Background Activity Moderator Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BasicDisplay
DISPLAY_NAME: BasicDisplay
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BasicRender
DISPLAY_NAME: BasicRender
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Beep
DISPLAY_NAME: Beep
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: bindflt
DISPLAY_NAME: Windows Bind Filter Driver
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: bowser
DISPLAY_NAME: Tarayici
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: cdrom
DISPLAY_NAME: CD-ROM S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CimFS
DISPLAY_NAME: CimFS
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CldFlt
DISPLAY_NAME: Windows Cloud Files Filter Driver
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CLFS
DISPLAY_NAME: Common Log (CLFS)
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CNG
DISPLAY_NAME: CNG
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Dfsc
DISPLAY_NAME: DFS Ad Alani Istemci S�r�c�s�
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: disk
DISPLAY_NAME: Disk S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DXGKrnl
DISPLAY_NAME: LDDM Graphics Subsystem
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: EhStorClass
DISPLAY_NAME: Enhanced Storage Filter Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: FileCrypt
DISPLAY_NAME: FileCrypt
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: FileInfo
DISPLAY_NAME: File Information FS MiniFilter
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: FltMgr
DISPLAY_NAME: FltMgr
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: fvevol
DISPLAY_NAME: BitLocker S�r�c� Sifrelemesi Filtre S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: GpuEnergyDrv
DISPLAY_NAME: GPU Energy Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: HTTP
DISPLAY_NAME: HTTP Hizmeti
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: intelpep
DISPLAY_NAME: Intel(R) G�� Altyapisi Eklenti S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: iorate
DISPLAY_NAME: Disk G/� Hiz Filtre S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: KSecDD
DISPLAY_NAME: KSecDD
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: KSecPkg
DISPLAY_NAME: KSecPkg
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: lltdio
DISPLAY_NAME: Baglanti Katmani Topolojisi Bulma Esleyicisi G/� S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: luafv
DISPLAY_NAME: UAC Dosyasi Sanallastirma
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MMCSS
DISPLAY_NAME: Multimedia Class Scheduler
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: mountmgr
DISPLAY_NAME: Baglama Noktasi Y�neticisi
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: mpsdrv
DISPLAY_NAME: Windows Defender Firewall Authorization Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: mrxsmb
DISPLAY_NAME: SMB MiniRedirector Sarmalayici ve Altyapisi
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: mrxsmb10
DISPLAY_NAME: SMB 1.x MiniRedirector
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: mrxsmb20
DISPLAY_NAME: SMB 2.0 MiniRedirector
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Msfs
DISPLAY_NAME: Msfs
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: msisadrv
DISPLAY_NAME: msisadrv
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MsQuic
DISPLAY_NAME: MsQuic
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: mssmbios
DISPLAY_NAME: Microsoft Sistem Y�netimi BIOS S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Mup
DISPLAY_NAME: Mup
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NDIS
DISPLAY_NAME: NDIS Sistemi S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NdisCap
DISPLAY_NAME: Microsoft NDIS Yakalama
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Ndu
DISPLAY_NAME: Windows Network Data Usage Monitoring Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NetBIOS
DISPLAY_NAME: NetBIOS Interface
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NetBT
DISPLAY_NAME: NetBT
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Npfs
DISPLAY_NAME: Npfs
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: npsvctrig
DISPLAY_NAME: Named pipe service trigger provider
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: nsiproxy
DISPLAY_NAME: NSI Proxy Service Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Null
DISPLAY_NAME: Null
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: partmgr
DISPLAY_NAME: B�l�m s�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: pci
DISPLAY_NAME: PCI Veri Yolu S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: pcw
DISPLAY_NAME: Performance Counters for Windows Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: pdc
DISPLAY_NAME: pdc
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PEAUTH
DISPLAY_NAME: PEAUTH
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Psched
DISPLAY_NAME: QoS Paket Zamanlayicisi
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: rdbss
DISPLAY_NAME: Yeniden Y�nlendirilen Arabellek Alt Sistemi
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: rdyboost
DISPLAY_NAME: ReadyBoost
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: rspndr
DISPLAY_NAME: Baglanti Katmani Topolojisi Bulma Yanitlayicisi
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SgrmAgent
DISPLAY_NAME: System Guard Runtime Monitor Agent
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: spaceport
DISPLAY_NAME: Depolama Alanlari S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: srv2
DISPLAY_NAME: Sunucu SMB 2.xxx S�r�c�s�
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: srvnet
DISPLAY_NAME: srvnet
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: storahci
DISPLAY_NAME: Microsoft Standart SATA AHCI S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: storqosflt
DISPLAY_NAME: Depolama QoS Filtre S�r�c�s�
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Tcpip
DISPLAY_NAME: TCP/IP Iletisim Kurallari S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: tcpipreg
DISPLAY_NAME: TCP/IP Registry Compatibility
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: tdx
DISPLAY_NAME: NetIO Eski TDI Destegi S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Telemetry
DISPLAY_NAME: Intel(R) Telemetri Hizmeti
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: VBoxGuest
DISPLAY_NAME: VirtualBox Guest Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: VBoxSF
DISPLAY_NAME: VirtualBox Shared Folders
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vdrvroot
DISPLAY_NAME: Microsoft Sanal S�r�c� Listeleyicisi
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Vid
DISPLAY_NAME: Vid
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: volmgr
DISPLAY_NAME: Birim Y�neticisi S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: volmgrx
DISPLAY_NAME: Dinamik Birim Y�neticisi
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: volsnap
DISPLAY_NAME: Birim G�lge Kopya s�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: volume
DISPLAY_NAME: Birim s�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vwififlt
DISPLAY_NAME: Virtual WiFi Filter Driver
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wcifs
DISPLAY_NAME: Windows Container Isolation
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Wdf01000
DISPLAY_NAME: �ekirdek Modu S�r�c� �er�eveleri hizmeti
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WdFilter
DISPLAY_NAME: Microsoft Defender Vir�sten Koruma Mini Filtre S�r�c�s�
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WdNisDrv
DISPLAY_NAME: Microsoft Defender Vir�sten Koruma Ag Inceleme Sistem S�r�c�s�
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WFPLWFS
DISPLAY_NAME: Microsoft Windows Filtering Platform
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WindowsTrustedRT
DISPLAY_NAME: Windows Trusted Execution Environment Class Extension
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WindowsTrustedRTProxy
DISPLAY_NAME: Microsoft Windows G�venilir �alisma Zamani G�venli Hizmeti
        TYPE               : 1  KERNEL_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Wof
DISPLAY_NAME: Windows Overlay File System Filter Driver
        TYPE               : 2  FILE_SYSTEM_DRIVER  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 3: sc query type service state all: 

SERVICE_NAME: AJRouter
DISPLAY_NAME: AllJoyn Y�nlendirici Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ALG
DISPLAY_NAME: Uygulama Katmani Ag Ge�idi Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: AppIDSvc
DISPLAY_NAME: Uygulama Kimligi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Appinfo
DISPLAY_NAME: Uygulama Bilgileri
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: AppReadiness
DISPLAY_NAME: Uygulama Hazir Olma Durumu
        TYPE               : 30  WIN32  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: AppXSvc
DISPLAY_NAME: AppX Deployment Service (AppXSVC)
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: AudioEndpointBuilder
DISPLAY_NAME: Windows Ses Bitis Noktasi Olusturucu
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Audiosrv
DISPLAY_NAME: Windows Ses
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: autotimesvc
DISPLAY_NAME: H�cresel Saat
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: AxInstSV
DISPLAY_NAME: ActiveX Y�kleyicisi (AxInstSV)
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BDESVC
DISPLAY_NAME: BitLocker S�r�c� Sifreleme Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BFE
DISPLAY_NAME: Temel Filtre Altyapisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BITS
DISPLAY_NAME: Arka Plan Akilli Aktarim Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BrokerInfrastructure
DISPLAY_NAME: Arka Plan G�revleri Altyapi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Browser
DISPLAY_NAME: Bilgisayar Tarayicisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BTAGService
DISPLAY_NAME: Bluetooth Ses Ag Ge�idi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BthAvctpSvc
DISPLAY_NAME: AVCTP hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: bthserv
DISPLAY_NAME: Bluetooth Destek Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: camsvc
DISPLAY_NAME: Yetenek Erisim Y�neticisi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CDPSvc
DISPLAY_NAME: Bagli Cihazlar Platformu Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CertPropSvc
DISPLAY_NAME: Sertifika Yayma
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ClipSVC
DISPLAY_NAME: Istemci Lisans Hizmeti (ClipSVC)
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: COMSysApp
DISPLAY_NAME: COM+ Sistem Uygulamasi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CoreMessagingRegistrar
DISPLAY_NAME: CoreMessaging
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CryptSvc
DISPLAY_NAME: Sifreleme Hizmetleri
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DcomLaunch
DISPLAY_NAME: DCOM Sunucusu Islem Baslaticisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: dcsvc
DISPLAY_NAME: dcsvc
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: defragsvc
DISPLAY_NAME: S�r�c�leri en iyi duruma getir
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DeviceAssociationService
DISPLAY_NAME: Aygit Iliskisi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DeviceInstall
DISPLAY_NAME: Aygit Y�kleme Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_PRESHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DevQueryBroker
DISPLAY_NAME: DevQuery Arka Plan Kesfi Aracisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Dhcp
DISPLAY_NAME: DHCP Istemcisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: diagnosticshub.standardcollector.service
DISPLAY_NAME: Microsoft (R) Diagnostics Hub'i Standart Toplayici Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: diagsvc
DISPLAY_NAME: Diagnostic Execution Service
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DiagTrack
DISPLAY_NAME: Bagli Kullanici Deneyimleri ve Telemetrisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_PRESHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DispBrokerDesktopSvc
DISPLAY_NAME: Ilke Hizmetini G�r�nt�le
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DisplayEnhancementService
DISPLAY_NAME: G�r�nt� Iyilestirme Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DmEnrollmentSvc
DISPLAY_NAME: Aygit Y�netimi Kayit Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: dmwappushservice
DISPLAY_NAME: Cihaz Y�netimi Kablosuz Uygulama Protokol� (WAP) Aninda Ileti Y�nlendirme Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Dnscache
DISPLAY_NAME: DNS Istemcisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DoSvc
DISPLAY_NAME: Teslim En Iyilestirme
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: dot3svc
DISPLAY_NAME: Kablolu Otomatik Yapilandirma
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DPS
DISPLAY_NAME: Tani Ilkesi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DsmSvc
DISPLAY_NAME: Aygit Kurulum Y�neticisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DsSvc
DISPLAY_NAME: Veri Paylasimi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DusmSvc
DISPLAY_NAME: Veri Kullanimi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Eaphost
DISPLAY_NAME: Genisletilebilir Kimlik Dogrulama Protokol�
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: edgeupdate
DISPLAY_NAME: Microsoft Edge Update Service (edgeupdate)
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: edgeupdatem
DISPLAY_NAME: Microsoft Edge Update Service (edgeupdatem)
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: EFS
DISPLAY_NAME: Sifreleme Dosya Sistemi (EFS)
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: embeddedmode
DISPLAY_NAME: Ekli Mod
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: EntAppSvc
DISPLAY_NAME: Kurumsal Uygulama Y�netimi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: EventLog
DISPLAY_NAME: Windows Olay G�nl�g�
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: EventSystem
DISPLAY_NAME: COM+ Olay Sistemi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Fax
DISPLAY_NAME: Faks
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: fdPHost
DISPLAY_NAME: Islev Bulma Saglayicisi Ana Bilgisayari
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: FDResPub
DISPLAY_NAME: Islev Bulma Kaynak Yayimi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: fhsvc
DISPLAY_NAME: Dosya Ge�misi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: FontCache
DISPLAY_NAME: Windows Yazi Tipi �nbellegi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: FrameServer
DISPLAY_NAME: Windows Kamera �er�eve Sunucusu
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: GameInputSvc
DISPLAY_NAME: GameInput Service
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: gpsvc
DISPLAY_NAME: Grup Ilkesi Istemcisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_PRESHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: GraphicsPerfSvc
DISPLAY_NAME: GraphicsPerfSvc
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: hidserv
DISPLAY_NAME: Insan Arabirim Cihazlari Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: HvHost
DISPLAY_NAME: HV Ana Bilgisayar Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: icssvc
DISPLAY_NAME: Windows Mobil Etkin Nokta Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: IKEEXT
DISPLAY_NAME: IKE ve AuthIP IPsec Anahtarlama Mod�lleri
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: InstallService
DISPLAY_NAME: Microsoft Store Y�kleme Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: iphlpsvc
DISPLAY_NAME: IP Yardimcisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: IpxlatCfgSvc
DISPLAY_NAME: IP �eviri Yapilandirma Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: KeyIso
DISPLAY_NAME: CNG Anahtar Yalitimi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: KtmRm
DISPLAY_NAME: Dagitilmis Islem D�zenleyicisi i�in KtmRm
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: LanmanServer
DISPLAY_NAME: Sunucu
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: LanmanWorkstation
DISPLAY_NAME: Is Istasyonu
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: lfsvc
DISPLAY_NAME: Cografi Konum Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: LicenseManager
DISPLAY_NAME: Windows Lisans Y�neticisi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: lltdsvc
DISPLAY_NAME: Baglanti Katmani Topoloji Bulma Esleyicisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: lmhosts
DISPLAY_NAME: TCP/IP NetBIOS Yardimcisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: LSM
DISPLAY_NAME: Yerel Oturum Y�neticisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: LxpSvc
DISPLAY_NAME: Dil Deneyimi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MapsBroker
DISPLAY_NAME: Indirilen Haritalar Y�neticisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: McpManagementService
DISPLAY_NAME: McpManagementService
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MicrosoftEdgeElevationService
DISPLAY_NAME: Microsoft Edge Elevation Service (MicrosoftEdgeElevationService)
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MixedRealityOpenXRSvc
DISPLAY_NAME: Windows Mixed Reality OpenXR Service
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: mpssvc
DISPLAY_NAME: Windows Defender G�venlik Duvari
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MSDTC
DISPLAY_NAME: Dagitilmis Islem D�zenleyicisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MSiSCSI
DISPLAY_NAME: Microsoft iSCSI Baslaticisi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: msiserver
DISPLAY_NAME: Windows Installer
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NaturalAuthentication
DISPLAY_NAME: Natural Kimlik Dogrulamasi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NcaSvc
DISPLAY_NAME: Ag Baglantisi Yardimcisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NcbService
DISPLAY_NAME: Ag Baglantisi Aracisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NcdAutoSetup
DISPLAY_NAME: Ag Baglantili Cihazlarin Otomatik Kurulumu
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Netlogon
DISPLAY_NAME: Netlogon
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Netman
DISPLAY_NAME: Ag Baglantilari
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: netprofm
DISPLAY_NAME: Ag Listesi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NetSetupSvc
DISPLAY_NAME: Ag Kurulum Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NetTcpPortSharing
DISPLAY_NAME: Net.Tcp Baglanti Noktasi Paylastirma Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NgcCtnrSvc
DISPLAY_NAME: Microsoft Passport Kapsayici
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NgcSvc
DISPLAY_NAME: Microsoft Passport
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: NlaSvc
DISPLAY_NAME: Ag Konumu Tanima
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: nsi
DISPLAY_NAME: Ag Depo Arabirimi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: p2pimsvc
DISPLAY_NAME: Esler Arasi Ag Olusturma Kimlik Y�neticisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: p2psvc
DISPLAY_NAME: Es Ag Gruplandirma
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PcaSvc
DISPLAY_NAME: Program Uyumluluk Yardimcisi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: perceptionsimulation
DISPLAY_NAME: Windows Algilama Benzetimi Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PerfHost
DISPLAY_NAME: Performans Sayaci DLL Konak
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PhoneSvc
DISPLAY_NAME: Telefon Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: pla
DISPLAY_NAME: Performans G�nl�kleri ve Uyarilari
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PlugPlay
DISPLAY_NAME: Tak ve Kullan
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PNRPAutoReg
DISPLAY_NAME: PNRP Makine Adi Yayin Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PNRPsvc
DISPLAY_NAME: Es Adi ��z�mleme Protokol�
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PolicyAgent
DISPLAY_NAME: IPsec Ilke Aracisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Power
DISPLAY_NAME: G��
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PrintNotify
DISPLAY_NAME: Yazici Uzantilari ve Bildirimleri
        TYPE               : 120  WIN32_SHARE_PROCESS  (interactive)
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ProfSvc
DISPLAY_NAME: Kullanici Profili Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PushToInstall
DISPLAY_NAME: Windows PushToInstall Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: QWAVE
DISPLAY_NAME: Kaliteli Windows Ses Video Deneyim
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RasAuto
DISPLAY_NAME: Uzaktan Erisim Otomatik Baglanti Y�neticisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RasMan
DISPLAY_NAME: Uzaktan Erisim Baglanti Y�neticisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RemoteAccess
DISPLAY_NAME: Y�nlendirme ve Uzaktan Erisim
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RemoteRegistry
DISPLAY_NAME: Uzak Kayit Defteri
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RetailDemo
DISPLAY_NAME: Perakende G�steri Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RmSvc
DISPLAY_NAME: Radyo Y�netimi Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RpcEptMapper
DISPLAY_NAME: RPC Bitis Noktasi Eslestiricisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RpcLocator
DISPLAY_NAME: Uzaktan Yordam �agrisi (RPC) Konumlandiricisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: RpcSs
DISPLAY_NAME: Uzaktan Yordam �agrisi (RPC)
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SamSs
DISPLAY_NAME: G�venlik Hesaplari Y�neticisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SCardSvr
DISPLAY_NAME: Akilli Kart
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ScDeviceEnum
DISPLAY_NAME: Akilli Kart Cihaz Numaralandirma Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Schedule
DISPLAY_NAME: G�rev Zamanlayici
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SCPolicySvc
DISPLAY_NAME: Akilli Kart Kaldirma Ilkesi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SDRSVC
DISPLAY_NAME: Windows Yedekleme
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: seclogon
DISPLAY_NAME: Ikincil Oturum A�ma
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SecurityHealthService
DISPLAY_NAME: Windows G�venligi Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, ACCEPTS_PRESHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SEMgrSvc
DISPLAY_NAME: �deme ve NFC/SE Y�neticisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SENS
DISPLAY_NAME: Sistem Olay Bildirim Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SensorDataService
DISPLAY_NAME: Algilayici Veri Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SensorService
DISPLAY_NAME: Algilayici Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SensrSvc
DISPLAY_NAME: Algilayici Izleme Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SessionEnv
DISPLAY_NAME: Uzak Masa�st� Yapilandirmasi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SgrmBroker
DISPLAY_NAME: System Guard �alisma Zamani Izleyicisi Aracisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SharedAccess
DISPLAY_NAME: Internet Baglantisi Paylasimi (ICS)
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SharedRealitySvc
DISPLAY_NAME: Uzamsal Veri Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ShellHWDetection
DISPLAY_NAME: Kabuk Donanim Algilamasi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: shpamsvc
DISPLAY_NAME: Shared PC Account Manager
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: smphost
DISPLAY_NAME: Microsoft Depolama Alanlari SMP
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SmsRouter
DISPLAY_NAME: Microsoft Windows SMS Y�nlendirme Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SNMPTRAP
DISPLAY_NAME: SNMP Yakalama
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: spectrum
DISPLAY_NAME: Windows Algilama Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Spooler
DISPLAY_NAME: Yazdirma Biriktiricisi
        TYPE               : 110  WIN32_OWN_PROCESS  (interactive)
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: sppsvc
DISPLAY_NAME: Yazilim Korumasi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SSDPSRV
DISPLAY_NAME: SSDP Bulma
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ssh-agent
DISPLAY_NAME: OpenSSH Authentication Agent
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SstpSvc
DISPLAY_NAME: G�venli Yuva T�nel Protokol� Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: StateRepository
DISPLAY_NAME: Durum Depo Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: stisvc
DISPLAY_NAME: Windows Resim Alma (WIA)
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: StorSvc
DISPLAY_NAME: Depolama Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: svsvc
DISPLAY_NAME: Nokta Dogrulayicisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: swprv
DISPLAY_NAME: Microsoft Yazilimi G�lge Kopya Saglayicisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SysMain
DISPLAY_NAME: SysMain
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: SystemEventsBroker
DISPLAY_NAME: Sistem Etkinlikleri Aracisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TabletInputService
DISPLAY_NAME: Dokunmatik Klavyeyi ve El Yazisi Paneli Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TapiSrv
DISPLAY_NAME: Telefon
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TermService
DISPLAY_NAME: Uzak Masa�st� Hizmetleri
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Themes
DISPLAY_NAME: Temalar
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TieringEngineService
DISPLAY_NAME: Depolama Katmanlari Y�netimi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TimeBrokerSvc
DISPLAY_NAME: Zaman Aracisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TokenBroker
DISPLAY_NAME: Web Hesap Y�neticisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TrkWks
DISPLAY_NAME: Dagitilmis Baglanti Izleme Istemcisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TroubleshootingSvc
DISPLAY_NAME: �nerilen Sorun Giderme Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: TrustedInstaller
DISPLAY_NAME: Windows Mod�l Y�kleyicisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: tzautoupdate
DISPLAY_NAME: Otomatik Saat Dilimi G�ncellestirici
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: UmRdpService
DISPLAY_NAME: Uzak Masa�st� Hizmetleri Kullanici Modu Baglanti Noktasi Yeniden Y�nlendiricisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: upnphost
DISPLAY_NAME: UPnP Aygit Ana Makinesi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: UserManager
DISPLAY_NAME: Kullanici Y�neticisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: UsoSvc
DISPLAY_NAME: Orchestrator Hizmeti'ni G�ncellestir
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: VacSvc
DISPLAY_NAME: Volumetrik Ses Olusturucu Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: VaultSvc
DISPLAY_NAME: Kimlik Bilgisi Y�neticisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: VBoxService
DISPLAY_NAME: VirtualBox Guest Additions Service
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vds
DISPLAY_NAME: Sanal Disk
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmicguestinterface
DISPLAY_NAME: Hyper-V Konuk Arabirimi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmicheartbeat
DISPLAY_NAME: Hyper-V Sinyal Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmickvpexchange
DISPLAY_NAME: Hyper-V Veri Degisimi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmicrdv
DISPLAY_NAME: Hyper-V Uzak Masa�st� Sanallastirma Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmicshutdown
DISPLAY_NAME: Hyper-V Konuk Kapatma Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmictimesync
DISPLAY_NAME: Hyper-V Zaman Esitleme Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmicvmsession
DISPLAY_NAME: Hyper-V PowerShell Direct Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: vmicvss
DISPLAY_NAME: Hyper-V Birim G�lge Kopyasi Isteyicisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: VSS
DISPLAY_NAME: Birim G�lge Kopyasi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: W32Time
DISPLAY_NAME: Windows Time
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WaaSMedicSvc
DISPLAY_NAME: Windows Update Medic Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WalletService
DISPLAY_NAME: C�zdan Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WarpJITSvc
DISPLAY_NAME: WarpJITSvc
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wbengine
DISPLAY_NAME: Blok D�zeyinde Yedekleme Altyapi Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WbioSrvc
DISPLAY_NAME: Windows Biyometrik Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Wcmsvc
DISPLAY_NAME: Windows Baglanti Y�neticisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wcncsvc
DISPLAY_NAME: Windows Simdi Baglan - Yapilandirma Dosyasi Kaydedici
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WdiServiceHost
DISPLAY_NAME: Tanilama Hizmeti Ana Bilgisayari
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WdiSystemHost
DISPLAY_NAME: Tanilama Sistemi Ana Bilgisayari
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WdNisSvc
DISPLAY_NAME: Microsoft Defender Vir�sten Koruma Ag Inceleme Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WebClient
DISPLAY_NAME: WebClient
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Wecsvc
DISPLAY_NAME: Windows Olay Toplayicisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WEPHOSTSVC
DISPLAY_NAME: Windows Sifreleme Saglayicisi Ana Bilgisayar Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wercplsupport
DISPLAY_NAME: Sorun Raporlari Denetim Masasi Destegi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WerSvc
DISPLAY_NAME: Windows Hata Raporlama Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WFDSConMgrSvc
DISPLAY_NAME: Wi-Fi Direct Hizmetler Baglanti Y�neticisi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WiaRpc
DISPLAY_NAME: Resim Alma Olaylari
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WinDefend
DISPLAY_NAME: Microsoft Defender Vir�sten Koruma Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WinHttpAutoProxySvc
DISPLAY_NAME: WinHTTP Web Proxy Otomatik Bulma Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (NOT_STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: Winmgmt
DISPLAY_NAME: Windows Y�netim Yardimcilari
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WinRM
DISPLAY_NAME: Windows Uzaktan Y�netim (WS-Management)
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wisvc
DISPLAY_NAME: Windows Insider Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WlanSvc
DISPLAY_NAME: Kablosuz Yerel Ag Otomatik Yapilandirma
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wlidsvc
DISPLAY_NAME: Microsoft Hesabi Oturum A�ma Yardimcisi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wlpasvc
DISPLAY_NAME: Yerel Profil Yardimcisi Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WManSvc
DISPLAY_NAME: Windows Y�netim Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wmiApSrv
DISPLAY_NAME: WMI Performans Bagdastiricisi
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WMPNetworkSvc
DISPLAY_NAME: Windows Media Player Ag Paylasimi Hizmeti
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: workfolderssvc
DISPLAY_NAME: �alisma Klas�rleri
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WpcMonSvc
DISPLAY_NAME: Ebeveyn Denetimleri
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WPDBusEnum
DISPLAY_NAME: Tasinabilir Aygit Numaralandirma Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WpnService
DISPLAY_NAME: Windows Aninda Iletme Bildirimleri Hizmeti
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wscsvc
DISPLAY_NAME: G�venlik Merkezi
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WSearch
DISPLAY_NAME: Windows Search
        TYPE               : 10  WIN32_OWN_PROCESS  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: wuauserv
DISPLAY_NAME: Windows Update
        TYPE               : 30  WIN32  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_PRESHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WwanSvc
DISPLAY_NAME: WWAN Otomatik Yapilandirma
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: XblAuthManager
DISPLAY_NAME: Xbox Live Kimlik Dogrulama Y�neticisi
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: XblGameSave
DISPLAY_NAME: Xbox Live Oyun Kaydetme
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: XboxGipSvc
DISPLAY_NAME: Xbox Accessory Management Service
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: XboxNetApiSvc
DISPLAY_NAME: Xbox Live Ag Hizmeti
        TYPE               : 20  WIN32_SHARE_PROCESS  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: AarSvc_3bc21
DISPLAY_NAME: Agent Activation Runtime_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BcastDVRUserService_3bc21
DISPLAY_NAME: Oyun DVR ve Yayin Kullanici Hizmeti_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: BluetoothUserService_3bc21
DISPLAY_NAME: Bluetooth Kullanici Destegi Hizmeti_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CaptureService_3bc21
DISPLAY_NAME: CaptureService_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: cbdhsvc_3bc21
DISPLAY_NAME: Pano Kullanici Hizmeti_3bc21
        TYPE               : f0   ERROR  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CDPUserSvc_3bc21
DISPLAY_NAME: Bagli Cihazlar Platformu Kullanici Hizmeti_3bc21
        TYPE               : f0   ERROR  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: ConsentUxUserSvc_3bc21
DISPLAY_NAME: ConsentUX_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: CredentialEnrollmentManagerUserSvc_3bc21
DISPLAY_NAME: CredentialEnrollmentManagerUserSvc_3bc21
        TYPE               : d0  USER_OWN_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DeviceAssociationBrokerSvc_3bc21
DISPLAY_NAME: DeviceAssociationBroker_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DevicePickerUserSvc_3bc21
DISPLAY_NAME: DevicePicker_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: DevicesFlowUserSvc_3bc21
DISPLAY_NAME: DevicesFlow_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: MessagingService_3bc21
DISPLAY_NAME: MesajlasmaHizmeti_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: OneSyncSvc_3bc21
DISPLAY_NAME: Ana Bilgisayari Esitle_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, IGNORES_SHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PimIndexMaintenanceSvc_3bc21
DISPLAY_NAME: Kisi Verileri_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: PrintWorkflowUserSvc_3bc21
DISPLAY_NAME: PrintWorkflow_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: UdkUserSvc_3bc21
DISPLAY_NAME: UDK Kullanici Hizmeti_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: UnistoreSvc_3bc21
DISPLAY_NAME: Kullanici Verilerini Depolama_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: UserDataSvc_3bc21
DISPLAY_NAME: Kullanici Verilerine Erisim_3bc21
        TYPE               : e0  USER_SHARE_PROCESS INSTANCE  
        STATE              : 1  STOPPED 
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0

SERVICE_NAME: WpnUserService_3bc21
DISPLAY_NAME: Windows Aninda Iletme Bildirimleri Kullanici Hizmeti_3bc21
        TYPE               : f0   ERROR  
        STATE              : 4  RUNNING 
                                (STOPPABLE, NOT_PAUSABLE, ACCEPTS_PRESHUTDOWN)
        WIN32_EXIT_CODE    : 0  (0x0)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 4: nslookup: 
Server:  dns.sse.cisco.com
Address:  2620:119:35::35

Name:    myip.opendns.com
Address:  2a00:1d34:ac88:f300:648f:42c6:c4dd:b771

ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 5: arp a: 

Interface: 192.168.1.102 --- 0x5
  Internet Address      Physical Address      Type
  192.168.1.1           e4-4e-12-5e-78-a0     dynamic   
  192.168.1.255         ff-ff-ff-ff-ff-ff     static    
  224.0.0.2             01-00-5e-00-00-02     static    
  224.0.0.22            01-00-5e-00-00-16     static    
  224.0.0.251           01-00-5e-00-00-fb     static    
  224.0.0.252           01-00-5e-00-00-fc     static    
  239.255.255.250       01-00-5e-7f-ff-fa     static    
  255.255.255.255       ff-ff-ff-ff-ff-ff     static    
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 6: route print: 
===========================================================================
Interface List
  5...08 00 27 e0 c8 8e ......Intel(R) PRO/1000 MT Desktop Adapter
  1...........................Software Loopback Interface 1
===========================================================================

IPv4 Route Table
===========================================================================
Active Routes:
Network Destination        Netmask          Gateway       Interface  Metric
          0.0.0.0          0.0.0.0      192.168.1.1    192.168.1.102     25
        127.0.0.0        255.0.0.0         On-link         127.0.0.1    331
        127.0.0.1  255.255.255.255         On-link         127.0.0.1    331
  127.255.255.255  255.255.255.255         On-link         127.0.0.1    331
      192.168.1.0    255.255.255.0         On-link     192.168.1.102    281
    192.168.1.102  255.255.255.255         On-link     192.168.1.102    281
    192.168.1.255  255.255.255.255         On-link     192.168.1.102    281
        224.0.0.0        240.0.0.0         On-link         127.0.0.1    331
        224.0.0.0        240.0.0.0         On-link     192.168.1.102    281
  255.255.255.255  255.255.255.255         On-link         127.0.0.1    331
  255.255.255.255  255.255.255.255         On-link     192.168.1.102    281
===========================================================================
Persistent Routes:
  None

IPv6 Route Table
===========================================================================
Active Routes:
 If Metric Network Destination      Gateway
  5    281 ::/0                     fe80::1
  1    331 ::1/128                  On-link
  5    281 2a00:1d34:ac88:f300::/64 On-link
  5    281 2a00:1d34:ac88:f300:648f:42c6:c4dd:b771/128
                                    On-link
  5    281 2a00:1d34:ac88:f300:ba56:661e:24a4:568d/128
                                    On-link
  5    281 fe80::/64                On-link
  5    281 fe80::c73f:eb12:2561:d842/128
                                    On-link
  1    331 ff00::/8                 On-link
  5    281 ff00::/8                 On-link
===========================================================================
Persistent Routes:
  None
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 7: netsh interface ip show dnsservers: 

Configuration for interface "Ethernet"
    DNS servers configured through DHCP:  192.168.1.1
    Register with which suffix:           Primary only

Configuration for interface "Loopback Pseudo-Interface 1"
    Statically Configured DNS Servers:    None
    Register with which suffix:           Primary only

ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 8: netsh interface ip show address: 

Configuration for interface "Ethernet"
    DHCP enabled:                         Yes
    IP Address:                           192.168.1.102
    Subnet Prefix:                        192.168.1.0/24 (mask 255.255.255.0)
    Default Gateway:                      192.168.1.1
    Gateway Metric:                       0
    InterfaceMetric:                      25

Configuration for interface "Loopback Pseudo-Interface 1"
    DHCP enabled:                         No
    IP Address:                           127.0.0.1
    Subnet Prefix:                        127.0.0.0/8 (mask 255.0.0.0)
    InterfaceMetric:                      75

ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 9: netsh interface show interface: 

Admin State    State          Type             Interface Name
-------------------------------------------------------------------------
Enabled        Connected      Dedicated        Ethernet

ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 10: getmac V: 

Connection Name Network Adapter Physical Address    Transport Name                                            
=============== =============== =================== ==========================================================
Ethernet        Intel(R) PRO/10 08-00-27-E0-C8-8E   \Device\Tcpip_{83E12BCD-E922-4879-A709-2A9FC0CBFB2E}      
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 11: ifconfig all: 

Windows IP Configuration

   Host Name . . . . . . . . . . . . : testWin
   Primary Dns Suffix  . . . . . . . : 
   Node Type . . . . . . . . . . . . : Hybrid
   IP Routing Enabled. . . . . . . . : No
   WINS Proxy Enabled. . . . . . . . : No
   DNS Suffix Search List. . . . . . : local

Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . : local
   Description . . . . . . . . . . . : Intel(R) PRO/1000 MT Desktop Adapter
   Physical Address. . . . . . . . . : 08-00-27-E0-C8-8E
   DHCP Enabled. . . . . . . . . . . : Yes
   Autoconfiguration Enabled . . . . : Yes
   IPv6 Address. . . . . . . . . . . : 2a00:1d34:ac88:f300:ba56:661e:24a4:568d(Preferred) 
   Temporary IPv6 Address. . . . . . : 2a00:1d34:ac88:f300:648f:42c6:c4dd:b771(Preferred) 
   Link-local IPv6 Address . . . . . : fe80::c73f:eb12:2561:d842%5(Preferred) 
   IPv4 Address. . . . . . . . . . . : 192.168.1.102(Preferred) 
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Lease Obtained. . . . . . . . . . : Sunday, October 12, 2025 4:41:43 AM
   Lease Expires . . . . . . . . . . : Sunday, October 12, 2025 5:41:41 AM
   Default Gateway . . . . . . . . . : fe80::1%5
                                       192.168.1.1
   DHCP Server . . . . . . . . . . . : 192.168.1.1
   DHCPv6 IAID . . . . . . . . . . . : 84410407
   DHCPv6 Client DUID. . . . . . . . : 00-01-00-01-30-7C-BD-0A-08-00-27-E0-C8-8E
   DNS Servers . . . . . . . . . . . : fe80::1%5
                                       192.168.1.1
                                       fe80::1%5
   NetBIOS over Tcpip. . . . . . . . : Enabled
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 12: ipconfig: 

Windows IP Configuration


Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . : local
   IPv6 Address. . . . . . . . . . . : 2a00:1d34:ac88:f300:ba56:661e:24a4:568d
   Temporary IPv6 Address. . . . . . : 2a00:1d34:ac88:f300:648f:42c6:c4dd:b771
   Link-local IPv6 Address . . . . . : fe80::c73f:eb12:2561:d842%5
   IPv4 Address. . . . . . . . . . . : 192.168.1.102
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : fe80::1%5
                                       192.168.1.1
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 13: ipconfig displaydns: 

Windows IP Configuration

    www.google.com
    ----------------------------------------
    Record Name . . . . . : www.google.com
    Record Type . . . . . : 28
    Time To Live  . . . . : 142
    Data Length . . . . . : 16
    Section . . . . . . . : Answer
    AAAA Record . . . . . : 2a00:1450:4017:813::2004


    www.google.com
    ----------------------------------------
    Record Name . . . . . : www.google.com
    Record Type . . . . . : 1
    Time To Live  . . . . : 128
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 142.251.140.4


    login.live.com
    ----------------------------------------
    Record Name . . . . . : login.live.com
    Record Type . . . . . : 5
    Time To Live  . . . . : 146
    Data Length . . . . . : 8
    Section . . . . . . . : Answer
    CNAME Record  . . . . : login.msa.msidentity.com


    Record Name . . . . . : login.msa.msidentity.com
    Record Type . . . . . : 5
    Time To Live  . . . . : 146
    Data Length . . . . . : 8
    Section . . . . . . . : Answer
    CNAME Record  . . . . : www.tm.lg.prod.aadmsa.trafficmanager.net


    Record Name . . . . . : www.tm.lg.prod.aadmsa.trafficmanager.net
    Record Type . . . . . : 5
    Time To Live  . . . . : 146
    Data Length . . . . . : 8
    Section . . . . . . . : Answer
    CNAME Record  . . . . : prdv4a.aadg.msidentity.com


    Record Name . . . . . : prdv4a.aadg.msidentity.com
    Record Type . . . . . : 5
    Time To Live  . . . . : 146
    Data Length . . . . . : 8
    Section . . . . . . . : Answer
    CNAME Record  . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.147.8


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.177.85


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.147.9


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.147.11


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.177.149


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.177.22


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.177.148


    Record Name . . . . . : www.tm.v4.a.prd.aadg.trafficmanager.net
    Record Type . . . . . : 1
    Time To Live  . . . . : 146
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 20.190.177.20


    resolver1.opendns.com
    ----------------------------------------
    Record Name . . . . . : resolver1.opendns.com
    Record Type . . . . . : 28
    Time To Live  . . . . : 3294
    Data Length . . . . . : 16
    Section . . . . . . . : Answer
    AAAA Record . . . . . : 2620:119:35::35


    resolver1.opendns.com
    ----------------------------------------
    Record Name . . . . . : resolver1.opendns.com
    Record Type . . . . . : 1
    Time To Live  . . . . : 3294
    Data Length . . . . . : 4
    Section . . . . . . . : Answer
    A (Host) Record . . . : 208.67.222.222


ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 14: tasklist V: 

Image Name                     PID Session Name        Session#    Mem Usage Status          User Name                                              CPU Time Window Title                                                            
========================= ======== ================ =========== ============ =============== ================================================== ============ ========================================================================
System Idle Process              0 Services                   0          8 K Unknown         NT AUTHORITY\SYSTEM                                     0:17:11 N/A                                                                     
System                           4 Services                   0        156 K Unknown         N/A                                                     0:00:06 N/A                                                                     
Registry                       124 Services                   0     74,180 K Unknown         N/A                                                     0:00:00 N/A                                                                     
smss.exe                       380 Services                   0      1,236 K Unknown         N/A                                                     0:00:00 N/A                                                                     
csrss.exe                      480 Services                   0      6,032 K Unknown         N/A                                                     0:00:00 N/A                                                                     
wininit.exe                    556 Services                   0      7,304 K Unknown         N/A                                                     0:00:00 N/A                                                                     
csrss.exe                      580 Console                    1      5,552 K Running         N/A                                                     0:00:00 N/A                                                                     
winlogon.exe                   660 Console                    1     12,028 K Unknown         N/A                                                     0:00:00 N/A                                                                     
services.exe                   704 Services                   0     10,352 K Unknown         N/A                                                     0:00:00 N/A                                                                     
lsass.exe                      724 Services                   0     19,548 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                    844 Services                   0     27,132 K Unknown         N/A                                                     0:00:01 N/A                                                                     
fontdrvhost.exe                872 Console                    1      4,232 K Unknown         N/A                                                     0:00:00 N/A                                                                     
fontdrvhost.exe                880 Services                   0      3,296 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                    960 Services                   0     14,008 K Unknown         N/A                                                     0:00:01 N/A                                                                     
svchost.exe                   1016 Services                   0      7,844 K Unknown         N/A                                                     0:00:00 N/A                                                                     
dwm.exe                        584 Console                    1     56,840 K Running         N/A                                                     0:00:01 DWM Notification Window                                                 
svchost.exe                   1012 Services                   0      7,952 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1148 Services                   0     15,408 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1192 Services                   0     10,040 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1200 Services                   0     12,100 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1244 Services                   0      6,280 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1252 Services                   0     19,060 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1260 Services                   0     12,196 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1388 Services                   0      9,984 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1464 Services                   0      8,008 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1524 Services                   0      7,752 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1548 Services                   0      7,452 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1620 Services                   0      8,080 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1700 Services                   0     12,036 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1708 Services                   0     12,396 K Unknown         N/A                                                     0:00:00 N/A                                                                     
VBoxService.exe               1780 Services                   0      7,272 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1872 Services                   0     10,004 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1884 Services                   0     46,652 K Unknown         N/A                                                     0:00:02 N/A                                                                     
svchost.exe                   1904 Services                   0      7,904 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1912 Services                   0      6,052 K Unknown         N/A                                                     0:00:00 N/A                                                                     
Memory Compression            2032 Services                   0          N/A Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1628 Services                   0      8,212 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1816 Services                   0      7,496 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1352 Services                   0      8,188 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2264 Services                   0     14,152 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2352 Services                   0      8,228 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2360 Services                   0     25,376 K Unknown         N/A                                                     0:00:04 N/A                                                                     
svchost.exe                   2368 Services                   0      6,664 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2376 Services                   0      9,616 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2456 Services                   0     14,656 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2560 Services                   0      7,480 K Unknown         N/A                                                     0:00:00 N/A                                                                     
spoolsv.exe                   2644 Services                   0     20,460 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2704 Services                   0     18,276 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2764 Services                   0      8,348 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2964 Services                   0      5,668 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3032 Services                   0     18,704 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3040 Services                   0     10,532 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3048 Services                   0     36,480 K Unknown         N/A                                                     0:00:01 N/A                                                                     
MsMpEng.exe                   3056 Services                   0    141,012 K Unknown         N/A                                                     0:00:05 N/A                                                                     
svchost.exe                   3064 Services                   0     16,236 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1720 Services                   0     12,556 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1768 Services                   0      5,848 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2800 Services                   0      9,420 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3108 Services                   0     10,960 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3192 Services                   0      5,760 K Unknown         N/A                                                     0:00:00 N/A                                                                     
SearchIndexer.exe             3484 Services                   0     35,180 K Unknown         N/A                                                     0:00:01 N/A                                                                     
svchost.exe                   3512 Services                   0    143,016 K Unknown         N/A                                                     0:00:06 N/A                                                                     
svchost.exe                   3804 Services                   0     18,756 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3864 Services                   0      7,476 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3896 Services                   0     22,568 K Unknown         N/A                                                     0:00:00 N/A                                                                     
NisSrv.exe                    4020 Services                   0      9,288 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   2424 Services                   0      8,708 K Unknown         N/A                                                     0:00:00 N/A                                                                     
sihost.exe                    4172 Console                    1     28,724 K Running         TESTWIN\vboxuser                                        0:00:01 N/A                                                                     
svchost.exe                   4200 Console                    1     17,884 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
svchost.exe                   4244 Console                    1     39,120 K Running         TESTWIN\vboxuser                                        0:00:00 Windows Push Notifications Platform                                     
taskhostw.exe                 4312 Console                    1     15,736 K Running         TESTWIN\vboxuser                                        0:00:00 Task Host Window                                                        
MicrosoftEdgeUpdate.exe       4320 Services                   0      1,068 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   4408 Services                   0      8,348 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   4480 Services                   0     21,160 K Unknown         N/A                                                     0:00:00 N/A                                                                     
ctfmon.exe                    4516 Console                    1     19,800 K Running         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
explorer.exe                  4688 Console                    1    143,924 K Running         TESTWIN\vboxuser                                        0:00:07 N/A                                                                     
svchost.exe                   4948 Services                   0     11,088 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   4272 Services                   0     16,800 K Unknown         N/A                                                     0:00:00 N/A                                                                     
WmiPrvSE.exe                  4428 Services                   0     12,576 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   5336 Services                   0     12,444 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   5392 Services                   0      6,008 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   5420 Services                   0      9,360 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   5472 Console                    1     17,484 K Running         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
StartMenuExperienceHost.e     5776 Console                    1     65,700 K Running         TESTWIN\vboxuser                                        0:00:00 Baslangi�                                                               
RuntimeBroker.exe             5904 Console                    1     26,328 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
SearchApp.exe                 6028 Console                    1    160,528 K Running         TESTWIN\vboxuser                                        0:00:02 Arama                                                                   
RuntimeBroker.exe             3776 Console                    1     29,324 K Running         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
SkypeApp.exe                  6384 Console                    1      5,568 K Running         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
RuntimeBroker.exe             6644 Console                    1     17,584 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
svchost.exe                   6912 Services                   0      9,324 K Unknown         N/A                                                     0:00:00 N/A                                                                     
WWAHost.exe                   7108 Console                    1     51,288 K Running         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
ApplicationFrameHost.exe      7116 Console                    1     29,848 K Running         TESTWIN\vboxuser                                        0:00:00 Office                                                                  
RuntimeBroker.exe             4476 Console                    1     13,668 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
smartscreen.exe               3452 Console                    1     27,732 K Running         TESTWIN\vboxuser                                        0:00:00 OLEChannelWnd                                                           
RuntimeBroker.exe             7328 Console                    1     17,032 K Running         TESTWIN\vboxuser                                        0:00:00 OleMainThreadWndName                                                    
SecurityHealthSystray.exe     8092 Console                    1      9,356 K Running         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
SecurityHealthService.exe     8132 Services                   0     14,940 K Unknown         N/A                                                     0:00:00 N/A                                                                     
VBoxTray.exe                  7068 Console                    1     10,764 K Running         TESTWIN\vboxuser                                        0:00:00 VBoxSharedClipboardClass                                                
OneDrive.exe                  7628 Console                    1     93,732 K Running         TESTWIN\vboxuser                                        0:00:01 N/A                                                                     
svchost.exe                   7684 Services                   0     15,756 K Unknown         N/A                                                     0:00:00 N/A                                                                     
WinStore.App.exe              1800 Console                    1     26,700 K Running         TESTWIN\vboxuser                                        0:00:00 Microsoft Store                                                         
RuntimeBroker.exe             2600 Console                    1     18,472 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
RuntimeBroker.exe             6488 Console                    1      8,180 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
svchost.exe                   8104 Services                   0      8,792 K Unknown         N/A                                                     0:00:00 N/A                                                                     
audiodg.exe                   2248 Services                   0     12,184 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   3812 Services                   0      4,868 K Unknown         N/A                                                     0:00:00 N/A                                                                     
ShellExperienceHost.exe       6692 Console                    1     49,028 K Running         TESTWIN\vboxuser                                        0:00:00 Yeni bildirim                                                           
RuntimeBroker.exe             6736 Console                    1     18,972 K Running         TESTWIN\vboxuser                                        0:00:00 OLEChannelWnd                                                           
SgrmBroker.exe                1568 Services                   0      8,552 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   8020 Services                   0     11,572 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   7444 Services                   0     11,196 K Unknown         N/A                                                     0:00:00 N/A                                                                     
svchost.exe                   1288 Console                    1     13,008 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
svchost.exe                   7564 Services                   0     13,844 K Unknown         N/A                                                     0:00:00 N/A                                                                     
WUDFHost.exe                   636 Services                   0      9,080 K Unknown         N/A                                                     0:00:00 N/A                                                                     
SearchProtocolHost.exe        5428 Services                   0     13,164 K Unknown         N/A                                                     0:00:00 N/A                                                                     
SearchFilterHost.exe          6392 Services                   0      9,188 K Unknown         N/A                                                     0:00:00 N/A                                                                     
SearchProtocolHost.exe        7716 Console                    1      8,316 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
Sabrina.exe                   8048 Console                    1     17,900 K Running         TESTWIN\vboxuser                                        0:00:00 OleMainThreadWndName                                                    
cmd.exe                       6956 Console                    1      5,252 K Running         TESTWIN\vboxuser                                        0:00:00 sabrina                                                                 
conhost.exe                   8064 Console                    1     14,748 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
svchost.exe                   3432 Services                   0      6,804 K Unknown         N/A                                                     0:00:00 N/A                                                                     
WmiPrvSE.exe                   608 Services                   0      9,036 K Unknown         N/A                                                     0:00:00 N/A                                                                     
tasklist.exe                  1696 Console                    1      9,800 K Unknown         TESTWIN\vboxuser                                        0:00:00 N/A                                                                     
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 15: net user: 

\\TESTWIN Kullanici Hesaplari

-------------------------------------------------------------------------------
Administrator            Guest                    VarsayilanHesap          
vboxuser                 WDAGUtilityAccount       
Komut basariyla tamamlandi.

ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 16: netsh show all: 
Wireless System Information Summary
(Time: 10/12/2025 4:44:39 AM T�rkiye Standart Saati)


======================================================================= 
============================== SHOW DRIVERS =========================== 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
============================= SHOW INTERFACES ========================= 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
=========================== SHOW HOSTED NETWORK ======================= 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
============================= SHOW SETTINGS =========================== 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
============================== SHOW FILTERS =========================== 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
=========================== SHOW CREATEALLUSER ======================== 
=======================================================================



======================================================================= 
============================= SHOW PROFILES =========================== 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
========================== SHOW PROFILES NAME=* ======================= 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
======================= SHOW NETWORKS MODE=BSSID ====================== 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.

======================================================================= 
======================= SHOW INTERFACE CAPABILITIES =================== 
=======================================================================

The Wireless AutoConfig Service (wlansvc) is not running.
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 17: netstat aon: 

Active Connections

  Proto  Local Address          Foreign Address        State           PID
  TCP    0.0.0.0:135            0.0.0.0:0              LISTENING       960
  TCP    0.0.0.0:445            0.0.0.0:0              LISTENING       4
  TCP    0.0.0.0:5040           0.0.0.0:0              LISTENING       4272
  TCP    0.0.0.0:49664          0.0.0.0:0              LISTENING       724
  TCP    0.0.0.0:49665          0.0.0.0:0              LISTENING       556
  TCP    0.0.0.0:49666          0.0.0.0:0              LISTENING       1252
  TCP    0.0.0.0:49667          0.0.0.0:0              LISTENING       1148
  TCP    0.0.0.0:49668          0.0.0.0:0              LISTENING       2644
  TCP    0.0.0.0:49669          0.0.0.0:0              LISTENING       704
  TCP    192.168.1.102:139      0.0.0.0:0              LISTENING       4
  TCP    192.168.1.102:49680    104.96.151.139:80      TIME_WAIT       0
  TCP    192.168.1.102:49688    98.64.238.3:443        ESTABLISHED     3452
  TCP    192.168.1.102:49693    98.64.238.3:443        ESTABLISHED     3452
  TCP    192.168.1.102:49695    20.190.147.8:443       TIME_WAIT       0
  TCP    192.168.1.102:49698    20.190.147.8:443       ESTABLISHED     7684
  TCP    192.168.1.102:49723    4.208.165.241:443      ESTABLISHED     3056
  TCP    [::]:135               [::]:0                 LISTENING       960
  TCP    [::]:445               [::]:0                 LISTENING       4
  TCP    [::]:49664             [::]:0                 LISTENING       724
  TCP    [::]:49665             [::]:0                 LISTENING       556
  TCP    [::]:49666             [::]:0                 LISTENING       1252
  TCP    [::]:49667             [::]:0                 LISTENING       1148
  TCP    [::]:49668             [::]:0                 LISTENING       2644
  TCP    [::]:49669             [::]:0                 LISTENING       704
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49684  [2a02:26f0:cb00::c3af:b342]:443  CLOSE_WAIT      6028
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49705  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49706  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49707  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49708  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49710  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49711  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49712  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49713  [2a02:26f0:cb00:1a2::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49714  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49715  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49716  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49717  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49718  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49719  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49720  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49721  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  TCP    [2a00:1d34:ac88:f300:648f:42c6:c4dd:b771]:49722  [2a02:26f0:cb00:1ac::2c1a]:80  TIME_WAIT       0
  UDP    0.0.0.0:5050           *:*                                    4272
  UDP    0.0.0.0:5353           *:*                                    2352
  UDP    0.0.0.0:5355           *:*                                    2352
  UDP    127.0.0.1:53354        *:*                                    3108
  UDP    192.168.1.102:137      *:*                                    4
  UDP    192.168.1.102:138      *:*                                    4
  UDP    [::]:5353              *:*                                    2352
  UDP    [::]:5355              *:*                                    2352
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 18: systeminfo: 

Host Name:                 TESTWIN
OS Name:                   Microsoft Windows 10 Home
OS Version:                10.0.19045 N/A Build 19045
OS Manufacturer:           Microsoft Corporation
OS Configuration:          Standalone Workstation
OS Build Type:             Multiprocessor Free
Registered Owner:          Windows Kullanicisi
Registered Organization:   
Product ID:                00326-10000-00000-AA105
Original Install Date:     10/12/2025, 4:26:14 AM
System Boot Time:          10/12/2025, 4:41:35 AM
System Manufacturer:       innotek GmbH
System Model:              VirtualBox
System Type:               x64-based PC
Processor(s):              1 Processor(s) Installed.
                           [01]: AMD64 Family 23 Model 113 Stepping 0 AuthenticAMD ~3593 Mhz
BIOS Version:              innotek GmbH VirtualBox, 12/1/2006
Windows Directory:         C:\Windows
System Directory:          C:\Windows\system32
Boot Device:               \Device\HarddiskVolume1
System Locale:             en-us;Ingilizce (A.B.D.)
Input Locale:              en-us;Ingilizce (A.B.D.)
Time Zone:                 (UTC+03:00) Istanbul
Total Physical Memory:     8,192 MB
Available Physical Memory: 6,412 MB
Virtual Memory: Max Size:  10,112 MB
Virtual Memory: Available: 8,509 MB
Virtual Memory: In Use:    1,603 MB
Page File Location(s):     C:\pagefile.sys
Domain:                    WORKGROUP
Logon Server:              \\TESTWIN
Hotfix(s):                 5 Hotfix(s) Installed.
                           [01]: KB5031988
                           [02]: KB5015684
                           [03]: KB5033372
                           [04]: KB5014032
                           [05]: KB5032907
Network Card(s):           1 NIC(s) Installed.
                           [01]: Intel(R) PRO/1000 MT Desktop Adapter
                                 Connection Name: Ethernet
                                 DHCP Enabled:    Yes
                                 DHCP Server:     192.168.1.1
                                 IP address(es)
                                 [01]: 192.168.1.102
                                 [02]: fe80::c73f:eb12:2561:d842
                                 [03]: 2a00:1d34:ac88:f300:648f:42c6:c4dd:b771
                                 [04]: 2a00:1d34:ac88:f300:ba56:661e:24a4:568d
Hyper-V Requirements:      A hypervisor has been detected. Features required for Hyper-V will not be displayed.
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 19: tree USERNAME: 
Folder PATH listing
Volume serial number is 000000EE 1A3B:82F6
C:\USERS\VBOXUSER
+---3D Objects
+---Contacts
+---Desktop
|   +---shared
|   |   +---Recognize the Target
|   |   |       bilmen gerekenler.txt
|   |   |       Sabrina.bat
|   |   |       Sabrina.exe
|   |   |       
|   |   \---System Volume Information
|   \---test
+---Documents
+---Downloads
+---Favorites
|   |   Bing.url
|   |   
|   \---Links
+---Links
|       Desktop.lnk
|       Downloads.lnk
|       
+---Music
+---OneDrive
+---Pictures
|   +---Camera Roll
|   \---Saved Pictures
+---Saved Games
+---Searches
|       winrt--{S-1-5-21-3661038300-3784393652-1306478804-1000}-.searchconnector-ms
|       
\---Videos
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
KOMUT 20: powershell location expose: 
Lat: NaN, Lon: NaN
ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo 
[Sun 10/12/2025  4:44:44.27]BILDI TOPLAMA SONA ERDI 
